// ========================================
// SHAGA NOTES CBT ENGINE v1.0
// Part 1 - Core Engine
// ========================================

let currentQuestion = 0;
let answers = new Array(questions.length).fill(null);

// ---------- HTML Elements ----------

const questionText = document.getElementById("question-text");
const questionNumber = document.getElementById("question-number");
const optionsDiv = document.getElementById("options");

const currentQuestionSpan =
document.getElementById("current-question");

const totalQuestionSpan =
document.getElementById("total-question");

const answeredSpan =
document.getElementById("answered");

const remainingSpan =
document.getElementById("remaining");

const progressFill =
document.getElementById("progress-fill");

const palette =
document.getElementById("palette");

const prevBtn =
document.getElementById("prevBtn");

const nextBtn =
document.getElementById("nextBtn");

const submitBtn =
document.getElementById("submitBtn");

totalQuestionSpan.innerHTML = questions.length;


// ========================================
// Load Question
// ========================================

function loadQuestion() {

    const q = questions[currentQuestion];

    questionNumber.innerHTML =
    "Question " + (currentQuestion + 1);

    questionText.innerHTML =
    q.question;

    currentQuestionSpan.innerHTML =
    currentQuestion + 1;

    optionsDiv.innerHTML = "";

    q.options.forEach((option,index)=>{

        const btn=document.createElement("button");

        btn.className="option";

        btn.innerHTML=option;

        if(answers[currentQuestion]===index){

            btn.style.background="#4CAF50";
            btn.style.color="white";

        }

        btn.onclick=function(){

            answers[currentQuestion]=index;

            updateProgress();

            createPalette();

            loadQuestion();

        };

        optionsDiv.appendChild(btn);

    });

    updateProgress();

    createPalette();

}// ========================================
// Progress Engine
// ========================================

function updateProgress(){

    let answered = answers.filter(a => a !== null).length;

    answeredSpan.innerHTML = answered;

    remainingSpan.innerHTML =
    questions.length - answered;

    let percent =
    ((currentQuestion + 1) / questions.length) * 100;

    progressFill.style.width = percent + "%";

}


// ========================================
// Question Palette
// ========================================

function createPalette(){

    palette.innerHTML = "";

    for(let i=0;i<questions.length;i++){

        const btn =
        document.createElement("button");

        btn.className = "palette-btn";

        btn.innerHTML = i + 1;

        if(i===currentQuestion){

            btn.style.background="#FFC107";
            btn.style.color="#000";

        }

        else if(answers[i]!==null){

            btn.style.background="#4CAF50";
            btn.style.color="#fff";

        }

        btn.onclick=function(){

            currentQuestion=i;

            loadQuestion();

        };

        palette.appendChild(btn);

    }

}


// ========================================
// Navigation
// ========================================

nextBtn.onclick=function(){

    if(currentQuestion < questions.length-1){

        currentQuestion++;

        loadQuestion();

    }

};

prevBtn.onclick=function(){

    if(confirm("Are you sure you want to submit the test?")){

        calculateResult();

    }

};
submitBtn.onclick=function(){
    if(currentQuestion>0){

        currentQuestion--;

        loadQuestion();

    }

};


// ========================================
// Initial Load
// ========================================

loadQuestion();
// ========================================
// TIMER ENGINE
// ========================================

let totalTime = 30 * 60; // 30 minutes

const timer =
document.getElementById("timer");

function startTimer(){

    const countdown = setInterval(function(){

        let minutes =
        Math.floor(totalTime / 60);

        let seconds =
        totalTime % 60;

        timer.innerHTML =
        String(minutes).padStart(2,"0")
        + ":" +
        String(seconds).padStart(2,"0");

        // Orange when 10 minutes remain
        if(totalTime<=600){

            timer.style.color="orange";

        }

        // Red when 5 minutes remain
        if(totalTime<=300){

            timer.style.color="red";

        }

        if(totalTime<=0){

            clearInterval(countdown);

            calculateResult();
            // ========================================
// RESULT ENGINE
// ========================================

function calculateResult(){

    let correct=0;

    let wrong=0;

    let skipped=0;

    answers.forEach((ans,index)=>{

        if(ans===null){

            skipped++;

        }

        else if(ans===questions[index].answer){

            correct++;

        }

        else{

            wrong++;

        }

    });

    let percentage=
    ((correct/questions.length)*100).toFixed(2);

    let grade="D";

    if(percentage>=90) grade="A+";
    else if(percentage>=80) grade="A";
    else if(percentage>=70) grade="B+";
    else if(percentage>=60) grade="B";
    else if(percentage>=50) grade="C";

    document.getElementById("correctCount").innerHTML=correct;

    document.getElementById("wrongCount").innerHTML=wrong;

    document.getElementById("skippedCount").innerHTML=skipped;

    document.getElementById("scoreCount").innerHTML=
    correct+" / "+questions.length;

    document.getElementById("percentageCount").innerHTML=
    percentage+"%";

    document.getElementById("gradeCount").innerHTML=
    grade;

    document.getElementById("resultModal").style.display="flex";

}

    let correct = 0;
    let wrong = 0;
    let skipped = 0;

    answers.forEach((ans,index)=>{

        if(ans===null){

            skipped++;

        }

        else if(ans===questions[index].answer){

            correct++;

        }

        else{

            wrong++;

        }

    });

    let percentage =
    ((correct/questions.length)*100).toFixed(2);

    let grade="F";

    if(percentage>=90) grade="A+";
    else if(percentage>=80) grade="A";
    else if(percentage>=70) grade="B+";
    else if(percentage>=60) grade="B";
    else if(percentage>=50) grade="C";
    else grade="D";

    alert(

"TEST COMPLETED\n\n" +

"Correct : "+correct+"\n"+

"Wrong : "+wrong+"\n"+

"Skipped : "+skipped+"\n\n"+

"Score : "+correct+" / "+questions.length+"\n\n"+

"Percentage : "+percentage+"%\n\n"+

"Grade : "+grade

    );

}

        }

        totalTime--;

    },1000);

}

startTimer();